
package com.yourcompany.workforcemgmt.dto;

import com.yourcompany.workforcemgmt.util.Status;
import com.yourcompany.workforcemgmt.util.Priority;
import lombok.Data;

import java.time.LocalDate;

@Data
public class TaskDto {
    private Long id;
    private String title;
    private Status status;
    private Priority priority;
    private LocalDate startDate;
    private LocalDate dueDate;
    private Long staffId;
}
