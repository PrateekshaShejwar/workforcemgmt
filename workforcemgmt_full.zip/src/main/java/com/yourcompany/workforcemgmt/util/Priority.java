
package com.yourcompany.workforcemgmt.util;

public enum Priority {
    HIGH, MEDIUM, LOW
}
