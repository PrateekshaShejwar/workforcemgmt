
package com.yourcompany.workforcemgmt.util;

public enum Status {
    ACTIVE, COMPLETED, CANCELLED
}
